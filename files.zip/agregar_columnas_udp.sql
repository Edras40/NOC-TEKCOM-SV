-- Agrega las columnas necesarias para que UDP calcule Lapso/Intervalo/Segundo,
-- igual que ya lo hace Casos Movistar. Seguro de correr aunque ya existan.
alter table casos_udp
  add column if not exists lapso text,
  add column if not exists intervalo text,
  add column if not exists segundo numeric;
